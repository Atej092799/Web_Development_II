var images = [
    {
        src: 'Anne-Curtis.jpg',
        title: 'ANNE CURTIS',
        description: 'Anne Curtis (born 17 February 1985) is a Filipina-Australian actress, model, television host, entrepreneur and recording artist.She has received numerous accolades throughout her career, including two FAMAS Awards, a Luna Award, two Metro Manila Film Festival Awards, and five PMPC Star Awards for Television. Additionally, she has also been nominated for two Gawad Urian Awards, and eight PMPC Star Awards for Movies.Curtis starred in several television series, including Hiram (2004–2005), Kampanerang Kuba (2005), Maging Sino Ka Man (2006–2007), Dyosa (2008).Curtis is one of the most infuential celebrities in the Philippines.Forbes Asia named her as one of the top 100 digital stars in the Asia-Pacific region. As of 2021, she remains as the Philippines top Instagram personality with over 17 million followers, and is also the 4th most followed Filipino celebrity on Facebook with over 18 million followers.'
    },
    {
        src: 'Jhong.jpg',
        title: 'Virgilio Viernes Hilario Jr.',
        description: 'Virgilio Viernes Hilario Jr. (born August 11, 1976), professionally known as Jhong Hilario, is a Filipino actor, dancer, television host, and politician. He is part of the Filipino dance group Streetboys. He is currently serving as a councilor of Makati from its 1st district since 2016. He is widely known for his antagonist roles in television; as Gary David in the 2010 remake of Mara Clara, and as Homer "Alakdan" Adlawan in FPJs Ang Probinsyano.He currently appears as a regular host on ABS-CBNs noontime variety show Its Showtime.Hilario decided to run for councilor in the 1st district of Makati under the United Nationalist Alliance ticket led by Abby Binay in 2016. In an interview, Hilario credited his father, Virgilio Sr., who served as a councilor for 9 years, as his main inspiration to run for the council seat.He was re-elected in 2019. He was the top vote getter on both elections.'
    },
    {
        src: 'Karylle.jpg',
        title: 'Ana Karylle Padilla Tatlonghari',
        description: 'Ana Karylle Padilla Tatlonghari (born March 22, 1981), known mononymously as Karylle, is a Filipino singer-songwriter, actress, dancer, TV host, model, athlete, musical theater performer, and entrepreneur. She is heralded as "OPMs Showbiz Royalty". She notably received a nomination for "Best Actress for TV Series-Drama" in one of Europe’s most prestigious television awards, Monte-Carlo TV Festival. In 2002, she won "Best New Artist" at the MTV Philippines. Her album titled "K" received a gold certification from PARI, while her albums titled "Time for letting Go" & "Roadtrip" all reach Platinum status in the Philippines. She also took part of the International Emmy-nominated telenovela Dahil May Isang Ikaw.'
    },
    {
        src: 'Ryan Bang.jpg',
        title: 'Bang Hyun-sung',
        description: 'Bang Hyun-sung (Korean: 방현성; Hanja: 方縣成; born June 16, 1991),[1] professionally known as Ryan Bang, is a South Korean host, singer, comedian, actor and television personality in the Philippines.[2] He is one of a few Korean expatriates to appear prominently in Philippine television, other notable expatriates are Sandara Park, Sam Oh and Grace Lee. He rose to fame in the Philippines when he joined the reality show Pinoy Big Brother: Teen Clash 2010, where he finished as a runner-up. He hosted his first show, 3ow Powhz!, which aired from late 2010 until early 2011 on Studio 23. He is a host of ABS-CBNs daily noontime variety show Its Showtime since 2012, and was a co-host of the Philippine comedy gag show Banana Sundae from 2010 to 2020.'
    },
    {
        src: 'Vhong.jpg',
        title: 'Ferdinand Hipolito Navarro',
        description: 'Ferdinand Hipolito Navarro (born January 4, 1977),[1] known professionally as Vhong Navarro, is a Filipino comedian, actor, dancer, recording artist, and television host. He is a regular host on ABS-CBNs noontime variety show Its Showtime. He is also part of the dance group Streetboys in the Philippines.His Occupation: Comedian, actor, dancer, recording artist,television host.'
    },
    {
        src: 'Vice-Ganda-1.jpg',
        title: 'Jose Marie Borja Viceral',
        description: 'Jose Marie Borja Viceral (born March 31, 1976), popularly known as Vice Ganda, is a Filipino comedian, talk show host, television presenter, actor, entrepreneur, and singer. He[a] is a regular host on ABS-CBNs noontime variety show Its Showtime, and has starred in several films, eight of which are considered to be the highest-grossing in Philippine cinema.During his stand-up routines, Vice Ganda uses observational comedy, situational irony and sarcasm in pertaining to Filipino culture and human sexuality. He is also the first openly LGBTQ endorser for Globe Telecom.'

        
    },
    // add more images and information 
]
function getInfo(id) {
    images.forEach(img => {
        // this will show the information when the image is clicked
        // just add more info
        if (img.title == id) {
            document.getElementById('title').innerHTML = img.title 
            document.getElementById('description').innerHTML = img.description
        }
    })
}

function render() {
    images.forEach(img => {
        var imgEl = document.createElement('img')
        imgEl.src = img.src
        imgEl.setAttribute('id', img.title)
        var gallery = document.getElementById('gallery')
        var imgContainer = document.createElement('div')
        imgContainer.setAttribute('class', 'img-container')
        imgContainer.appendChild(imgEl)
        gallery.appendChild(imgContainer)
        document.getElementById(img.title).addEventListener("click", function (e) {
            getInfo(e.target.id)
        })
    })
}

window.onload = render