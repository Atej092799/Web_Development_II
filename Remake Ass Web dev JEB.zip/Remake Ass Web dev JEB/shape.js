$(document).ready(function () {

    $('.shape-container').click((e) => {
        let currentShape = $(e.currentTarget).children().first().attr('class');
        $('#grid').css('border', 'none')
        let child = $('#grid').children().first();


        let currentClass = child.attr('class')

        if (currentClass) { //check if there is a class
            child.removeClass(currentClass); //remove the previous class
        }

        child.addClass(currentShape); // add the new class
        child = $('#grid').children().first();
        getStyles(child, currentShape, true);

    })
});