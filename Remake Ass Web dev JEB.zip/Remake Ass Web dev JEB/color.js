$(document).ready(function () {

    function getStyles(element, className, shape = false) {

        const styles = {
            height: element.css('height'),
            width: element.css('width'),
        }
        if (!shape) {
            styles['background-color'] = element.css('background-color');
        }

        $('#style-list').children().first().text("." + className + "\n" + JSON.stringify(styles))
    }


    $('.color-container').click((e) => {
        let currentShape = $(e.currentTarget).children().first().attr('class');
        $('#grid').css('border', 'none')
        let child = $('#grid').children().first();

        let currentClass = child.attr('class')

        if (currentClass) { //check if there is a class
            child.removeClass(currentClass); //remove the previous class
        }
        child.addClass(currentShape); // add the new class
        child = $('#grid').children().first();
        getStyles(child, currentShape.split(" ")[1]);


    })
    window.getStyles = getStyles
});